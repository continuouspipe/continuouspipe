module.exports = function(name) {
    return `Yo yo ${name} - welcome to Encore!`;
};