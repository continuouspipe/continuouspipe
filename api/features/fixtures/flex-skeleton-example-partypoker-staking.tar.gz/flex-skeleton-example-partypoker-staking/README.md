# Staking Prototype

```bash
> brew install node yarn make
> composer install
> yarn install
> make assets
> make serve
```
