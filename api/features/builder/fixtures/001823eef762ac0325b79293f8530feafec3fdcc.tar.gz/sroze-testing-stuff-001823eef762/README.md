# PHP example application

This is a Silex application that is used as demonstration purpose to deploy Docker-based applications.

## Start locally

In order to have useful feature such as the DNS resolution, you can start the application with [dock-cli](https://github.com/inviqa/dock-cli).

```
dock-cli start
```

*Note*: you can also start the application with `docker-compose`.
