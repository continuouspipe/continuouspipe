```
composer create-project symfony/skeleton:~3.3
```
